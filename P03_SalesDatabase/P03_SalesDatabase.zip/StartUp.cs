﻿using System;
using Microsoft.EntityFrameworkCore;
using P03_SalesDatabase.Data;

namespace P03_SalesDatabase
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //var connectionString = "Server=.\\SQLEXPRESS;Database=Sales;Integrated Security=true";

            //var optionsBuilder = new DbContextOptionsBuilder<SalesContext>();

            //optionsBuilder.UseSqlServer(connectionString, s => s.MigrationsAssembly("P03_SalesDatabase"));
        }
    }
}
